#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 14:49:58 2026

@author: k.bradley
"""
# Marketing Conversion Prediction
# Goal: Predict whether a customer will subscribe to a term deposit.

import sys
import pandas as pd
import numpy as np
import sklearn
import matplotlib.pyplot as plt

print("Project setup is working!")
print("Python version:", sys.version.split()[0])
print("pandas version:", pd.__version__)
print("scikit-learn version:", sklearn.__version__)

# Step 2: Download and load the bank marketing dataset

from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile
from io import BytesIO

# Keep the data beside this Python script
data_folder = Path(__file__).resolve().parent / "data"
data_folder.mkdir(exist_ok=True)

csv_path = data_folder / "bank-additional-full.csv"

# Download only if we do not already have the file
if not csv_path.exists():
    print("Downloading the dataset...")

    url = "https://archive.ics.uci.edu/static/public/222/bank+marketing.zip"

    with urlopen(url, timeout=60) as response:
        outer_zip = ZipFile(BytesIO(response.read()))

    inner_zip = ZipFile(BytesIO(outer_zip.read("bank-additional.zip")))

    csv_path.write_bytes(
        inner_zip.read("bank-additional/bank-additional-full.csv")
    )

# This file separates its columns with semicolons
df = pd.read_csv(csv_path, sep=";")

print("\nDataset loaded!")
print("Rows and columns:", df.shape)
print("\nFirst five records:")
print(df.head())

# Step 3: Check data quality and subscription outcomes

print("\nCOLUMN NAMES:")
print(df.columns.tolist())

print("\nMISSING VALUES:")
print(df.isna().sum())

print("\nUNKNOWN VALUES:")
text_columns = df.select_dtypes(include=["object", "string"])
print(text_columns.eq("unknown").sum())

print("\nEXACT DUPLICATE ROWS:")
print(df.duplicated().sum())

print("\nSUBSCRIPTION COUNTS:")
print(df["y"].value_counts())

print("\nSUBSCRIPTION PERCENTAGES:")
print((df["y"].value_counts(normalize=True) * 100).round(2))

# Step 4: Select features and create ordered data splits

features = [
    "job",
    "education",
    "default",
    "housing",
    "loan",
    "previous",
    "poutcome"
]

# X contains the inputs; y contains the answer
X = df[features].copy()
y = df["y"].map({"no": 0, "yes": 1})

assert y.notna().all(), "Unexpected subscription label found."

# Preserve the dataset's chronological row order
train_end = int(len(df) * 0.60)
validation_end = int(len(df) * 0.80)

X_train = X.iloc[:train_end].copy()
y_train = y.iloc[:train_end].copy()

X_val = X.iloc[train_end:validation_end].copy()
y_val = y.iloc[train_end:validation_end].copy()

X_test = X.iloc[validation_end:].copy()
y_test = y.iloc[validation_end:].copy()

print("\nDATA SPLITS:")
print("Training records:", len(X_train))
print("Validation records:", len(X_val))
print("Test records:", len(X_test))

print("\nDEVELOPMENT SUBSCRIPTION RATES:")
print(f"Training: {y_train.mean():.2%}")
print(f"Validation: {y_val.mean():.2%}")
# Step 5: Build a preprocessing and modeling pipeline

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

categorical_features = [
    "job", "education", "default",
    "housing", "loan", "poutcome"
]

numeric_features = ["previous"]

preprocessor = ColumnTransformer(
    transformers=[
        (
            "categories",
            OneHotEncoder(handle_unknown="ignore"),
            categorical_features
        ),
        (
            "numbers",
            StandardScaler(),
            numeric_features
        )
    ]
)

logistic_model = Pipeline(
    steps=[
        ("preprocessing", preprocessor),
        (
            "model",
            LogisticRegression(max_iter=2000, random_state=42)
        )
    ]
)

# Learn from the training records only
logistic_model.fit(X_train, y_train)

# Generate subscription scores for validation records
val_probabilities = logistic_model.predict_proba(X_val)[:, 1]

print("\nFIRST MODEL TRAINED!")
print("First 10 validation subscription scores:")
print(np.round(val_probabilities[:10], 4))
# Step 6: Evaluate predictions on validation data only

from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
    brier_score_loss
)

# Baseline: give every record the training subscription rate
baseline_probabilities = np.full(len(y_val), y_train.mean())

def evaluate_scores(actual, probabilities):
    return {
        "Average precision": average_precision_score(
            actual, probabilities
        ),
        "ROC-AUC": roc_auc_score(actual, probabilities),
        "Brier score": brier_score_loss(actual, probabilities)
    }

validation_results = pd.DataFrame({
    "Baseline": evaluate_scores(y_val, baseline_probabilities),
    "Logistic regression": evaluate_scores(y_val, val_probabilities)
}).T

print("\nVALIDATION MODEL COMPARISON:")
print(validation_results.round(4))
