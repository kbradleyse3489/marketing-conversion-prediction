# Your project walkthrough

## A simple 60-second explanation
“This project asks whether information available before a bank marketing call can help rank likely subscribers. I started with logistic regression, compared a fixed random forest, and used chronological splits so later observations stayed separate. I chose the model on validation average precision, then evaluated it on a held-out later period. The forest barely won that criterion, but the final results were weak and badly undercalibrated. The main lesson was that changing customer outcomes across time can make attractive-looking metrics misleading. I would not deploy this model without more recent data and stronger validation.”

Use this after reviewing the code and results. Clearly describe AI-assisted implementation if asked. Do not claim client work, deployment, measured revenue gains or sole authorship of additions you have not reviewed.

## What to open, in order
1. `original/marketing_conversion.py`: your original Steps 1–6, untouched.
2. `marketing_conversion.py`: `load_data`, `split_data`, and `build_models` show where the inputs and model choices come from.
3. `reports/validation_metrics.csv`: why the forest was selected on AP, and why that is a narrow result.
4. `reports/frozen_model_decision.json`: choices fixed before test scoring.
5. `reports/test_metrics.csv` and `figures/01_outcome_drift.png`: the honest outcome, not just the best metric.
6. `walkthrough.ipynb`: a readable, executed guide to charts and evidence.
7. `tests/test_project.py`: what was checked automatically.

## Questions you should be able to answer
- Why not use call duration? It is only known after a call and would leak future information into a pre-call prediction.
- Why not shuffle? The data is ordered over time; later observations are a more realistic challenge than mixing periods. No claim of perfect temporal/customer independence is made.
- Why AP? The positive class is relatively uncommon during training. AP summarizes positive-class ranking, but is prevalence-dependent, so ROC-AUC and calibration matter too.
- Why not accuracy? Predicting “no” for everyone can look accurate while missing subscribers.
- Why retain unknown? It is recorded information about missing/unknown answers, not a null value to silently discard.
- Why RF? It narrowly won the prespecified validation criterion, not all metrics. No statistical superiority was established.
- Why no deployment? Scores severely underpredict later conversion prevalence and test discrimination is weak.
- What would you change next? More recent data, customer identifiers where lawful, better temporal validation, calibration and fairness checks, with a fresh final holdout. Do not tune on this test set.
- Does 1.126x lift mean more sales? No. It describes historical subscriber concentration in a selected group, not causal sales gains.

## Project presentation
A modest skills line: “Evaluated logistic regression and random-forest conversion models using chronological validation, leakage-aware preprocessing, ranking metrics and distribution-drift diagnostics on public banking data.”

Before publishing: run the notebook locally, read the limitation section, decide how you want to acknowledge AI assistance, and review every claim. No files have been published for you.

## Evaluation history clarification

The same final row block was examined in earlier project work. This package therefore reports a repeated holdout evaluation, not a new independent test. Model selection in this script uses validation average precision; further tuning requires a new evaluation design.
