"""Smoke/integrity tests; no final-model refit or holdout tuning."""
import hashlib
import json
from pathlib import Path
import sys
import unittest
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import marketing_conversion as project

class ProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df, cls.sha = project.load_data()
        cls.splits = project.split_data(cls.df)
    def test_original_preserved(self):
        original=(project.ROOT/'original/marketing_conversion.py').read_bytes()
        self.assertEqual(len(original),5023)
        self.assertEqual(hashlib.sha256(original).hexdigest(),'e4fb56498d32b51d4d347ea8fd323993f597ce8d9435eb89e65d1e892b038bef')
    def test_dataset_and_checksum(self):
        self.assertEqual(self.df.shape,(41188,21))
        q=json.loads((project.ROOT/'reports/data_quality.json').read_text())
        self.assertEqual(self.sha,q['dataset_sha256'])
        self.assertEqual(int(self.df.duplicated().sum()),12)
    def test_disjoint_ordered_splits(self):
        tr,va,te=[self.splits[k] for k in ['train','validation','test']]
        self.assertEqual([len(tr),len(va),len(te)],[24712,8238,8238])
        self.assertLess(tr.index.max(),va.index.min()); self.assertLess(va.index.max(),te.index.min())
        self.assertEqual(len(set(tr.index)|set(va.index)|set(te.index)),len(self.df))
    def test_no_current_call_or_target_features(self):
        self.assertEqual(project.FEATURES,['job','education','default','housing','loan','previous','poutcome'])
        self.assertNotIn('duration',project.FEATURES);self.assertNotIn('y',project.FEATURES)
    def test_selection_uses_validation_ap(self):
        d=json.loads((project.ROOT/'reports/frozen_model_decision.json').read_text())
        v=pd.read_csv(project.ROOT/'reports/validation_metrics.csv',index_col=0)
        self.assertEqual(d['selected_model'],v.loc[list(project.build_models()),'average_precision'].idxmax())
        self.assertFalse(d['test_used_for_selection']);self.assertFalse(d['refit_on_validation'])
    def test_saved_holdout_scores_and_metrics(self):
        p=pd.read_csv(project.ROOT/'reports/holdout_predictions.csv')
        self.assertEqual(p.row_index.tolist(),self.splits['test'].index.tolist())
        self.assertTrue(p.score.between(0,1).all())
        self.assertEqual(p.actual_subscription.tolist(),self.splits['test'].y.eq('yes').astype(int).tolist())
        actual=project.evaluate(p.actual_subscription,p.score)
        expected=pd.read_csv(project.ROOT/'reports/test_metrics.csv',index_col=0).loc['Random forest']
        for key,value in actual.items(): self.assertAlmostEqual(value,expected[key],places=12)
    def test_unseen_categories_are_supported(self):
        # Small development-only smoke fit; final model is not touched.
        train=self.splits['train'].iloc[:4000]
        model=project.build_models()['Logistic regression']
        model.fit(train[project.FEATURES],train.y.eq('yes').astype(int))
        sample=train[project.FEATURES].iloc[:1].copy();sample.loc[:,'job']='never_seen_category'
        p=model.predict_proba(sample)
        self.assertEqual(p.shape,(1,2));self.assertTrue(np.isfinite(p).all())
    def test_ranking_known_example(self):
        result=project.top_fraction(np.array([1,0,1,0]),np.array([.9,.8,.7,.1]),.5)
        self.assertEqual(result['selected_records'],2);self.assertEqual(result['precision'],.5)

if __name__=='__main__': unittest.main()
