# Marketing Conversion Prediction
## Keisha Walker | Research project

**Can historical pre-contact information rank likely term-deposit subscribers?**
This project extends the actual uploaded `marketing_conversion.py` through a reproducible, deliberately modest model comparison. The result is a useful example of evaluation discipline and distribution drift, **not a production-ready prediction system**.

## Project visuals

![Subscription rates across ordered splits](reports/figures/01_outcome_drift.png)

![Validation precision and recall](reports/figures/02_validation_precision_recall.png)

## Start here
1. Read `docs/Marketing_Conversion_Prediction_Case_Study.pdf` for the concise story.
2. Open `walkthrough.ipynb` for an executed tour of the saved evidence.
3. Read `WALKTHROUGH.md` to practice explaining the project.
4. Inspect `marketing_conversion.py`, `reports/`, and `tests/` for the implementation and checks.

## What was preserved and added
- `original/marketing_conversion.py` is the uploaded file, unchanged. It covers data loading, quality checks, seven features, chronological splitting, logistic regression and validation evaluation (Steps 1–6).
- The root script adds a fixed random-forest comparator, explicit validation-only selection, one final selected-model holdout evaluation, ranking diagnostics, validation-only permutation importance and reusable outputs.
- The extension, documentation and checks were developed with AI assistance. Review and understand them before presenting them as your work. No publication, deployment or GitHub push has been performed.
- This is not the earlier starter ZIP and does not incorporate its performance claims.

## Run locally (Mac, Linux or Windows)
Python 3.12 is the tested version. Extract the ZIP first; do not run inside the ZIP.

```sh
cd Marketing_Conversion_Prediction
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python marketing_conversion.py
python -m unittest discover -s tests -v
python -m notebook walkthrough.ipynb
```

On Windows use `py -3.12 -m venv .venv`, then `.venv\Scripts\activate` instead of the first two Python/activation commands. In Spyder, set its interpreter to this environment and run the root script. Script paths are resolved relative to the script, not the current working directory.

The extracted CSV is included under its CC BY 4.0 license so the analysis can run offline after dependency installation. If removed, the script downloads it from UCI. The script saves metrics and figures under `reports/` and overwrites those generated outputs on each deliberate rerun. It does not save or load pickle/joblib models. The notebook displays saved outputs without retraining; the script is the single implementation source. All eight notebook code cells were executed with in-process IPython and captured outputs. Separate Jupyter-kernel launch was blocked by sandbox local-socket restrictions, so native Jupyter UI/kernel execution was not verified here.

## Research design
- Public UCI `bank-additional-full.csv`: 41,188 observations, 20 input columns plus target `y`, ordered by date. Rows are contacts/observations, not verified unique people. The data is from Portuguese bank campaigns, May 2008–November 2010.
- Preserve seven inputs: job, education, default, housing, loan, previous, poutcome. Exclude current-call `duration` because it is unknown before a call. Prior campaign fields are assumed available at decision time; a real system must verify that assumption.
- Preserve order: 24,712 training rows, 8,238 validation rows, 8,238 final test rows. No random shuffle, stratification or customer-group separation is claimed. The source has no stable customer ID and no full exact timestamps.
- Fit one-hot encoding and scaling only on training data. Preserve explicit `unknown` categories; ignore unseen categories safely. Twelve exact duplicate rows are retained to preserve the original design; exact full-row overlaps across splits are reported, not treated as proof of customer independence.
- Train the unchanged logistic baseline and one fixed forest (300 trees, depth 8, minimum leaf 30, seed 42). No broad search. Choose validation average precision (AP); logistic wins an exact tie. AP emphasizes positive-class ranking, but does not make other metrics irrelevant.
- Freeze selection, 20% illustrative contact capacity and parameters before holdout scoring. Do not refit using validation. Evaluate only the selected model and fixed training-rate baseline on the holdout. Do not retune on these test results.

## Verified results
| Model / split | Average precision | ROC-AUC | Brier score (lower is better) |
|---|---:|---:|---:|
| Training-rate baseline / validation | 0.1107 | 0.5000 | 0.1024 |
| Logistic regression / validation | 0.1457 | 0.5718 | 0.1020 |
| Random forest / validation | 0.1478 | 0.5610 | 0.1020 |
| Selected random forest / test | 0.3393 | 0.5376 | 0.2796 |
| Training-rate baseline / test | 0.3083 | 0.5000 | 0.2810 |

RF narrowly wins the chosen validation AP criterion by about 0.0021, while logistic has better validation ROC-AUC and slightly better Brier score. This is not evidence of statistically significant or broad RF superiority.

The subscription rate changes from 4.81% (train) to 11.07% (validation) to 30.83% (test). Higher test AP alone does not mean the model improved: AP depends on class prevalence. Test ROC-AUC 0.5376 shows weak discrimination. Holdout scores average about 5.02% against actual prevalence 30.83%, indicating severe underprediction; use them as uncalibrated ranking scores, not reliable conversion probabilities.

At the illustrative top-20% capacity, 1,648 test observations contain 572 subscribers (34.71% precision, 22.52% recall, 1.126x prevalence). This is retrospective concentration, **not incremental conversions, revenue or causal uplift**. The capacity is a demonstration, not a profit-optimized policy. Ties are broken deterministically by row order; real operational tie handling would need a documented policy.

## Quality, limits and responsible use
- No null values, but explicit `unknown` values are common, especially default (8,597). Missingness is not the same as complete information.
- Same-customer dependence cannot be ruled out. Duplicate retention and historical chronological regime changes limit inference.
- No confidence intervals, temporal cross-validation, external validation, fairness audit, economic costs or campaign experiments were completed. A single split is limited evidence.
- Job/education and financial-status fields can encode sensitive socioeconomic information or proxies. This artifact is public-data research, not a tool for credit eligibility, access to services or real customer targeting. Before operational use, verify lawful purpose, consent, feature availability, fairness and privacy requirements.
- Next experiment: collect more recent representative data; pre-register rolling temporal validation and train/calibrate only on development windows; reserve a new untouched final test. A later live randomized campaign would be needed to assess incremental business impact. Do not recycle this holdout for optimization and call it new evidence.

## Reproduction and provenance
`reports/run_environment.json` records actual versions; `reports/data_quality.json` records the dataset checksum. `reports/frozen_model_decision.json` records selection choices. Original baseline reproduced in this environment; training/validation were rerun once to correct a chart's constant-baseline presentation and verify exact AP equality, without repeating or tuning the final test evaluation. Tests inspect saved test predictions rather than retraining the test model.

## Data source and license
Moro, S., Rita, P., & Cortez, P. (2014). *Bank Marketing* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5K306

Dataset page: https://archive.ics.uci.edu/dataset/222/bank+marketing
License: Creative Commons Attribution 4.0 International, https://creativecommons.org/licenses/by/4.0/
The CSV is redistributed unchanged. Derived metrics, scores and figures are new analysis, not source labels or an endorsement by the data creators. See `DATA_ATTRIBUTION.md`.

## Evaluation history clarification

The same final row block was examined in earlier project work. This package therefore reports a repeated holdout evaluation, not a new independent test. Model selection in this script uses validation average precision; further tuning requires a new evaluation design.
